import java.io.BufferedReader;
import java.io.DataOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.Socket;
import java.util.ArrayList;

public class Client_Thread extends Thread {
	Socket connectionSocket;
	int ID;
	String clientSentence;
	String capitalizedSentence;
	DataOutputStream outToClient;
	BufferedReader inFromClient;
	ArrayList<Integer> avg1 = new ArrayList<Integer>();
	ArrayList<Integer> avg2 = new ArrayList<Integer>();
	int finalav;

	// lazm n3ml constructor 3shan ya5od socket bta3 client da
	public static int average(ArrayList<Integer>x) {
		int result=0;
	
		for(int i=0;i<x.size();i++) {
			result+=x.get(i);
		}
		return result/x.size();
	}
	public Client_Thread(Socket ClientSocket, int ID) {
		connectionSocket = ClientSocket;
		ID = this.ID;
	}

	public void run(){
		try {
			inFromClient = new BufferedReader(new
					InputStreamReader(connectionSocket.getInputStream()));
		} catch (IOException e3) {
			// TODO Auto-generated catch block
			e3.printStackTrace();
		} 

	
	try {
		outToClient = new DataOutputStream(connectionSocket.getOutputStream());
	} catch (IOException e2) {
		// TODO Auto-generated catch block
		e2.printStackTrace();
	} 

	while(true){
			try {
				clientSentence = inFromClient.readLine();
				if(clientSentence.equals("I am Sensor 1")) {
					int num=Integer.parseInt(inFromClient.readLine());
					avg1.add(num);
					finalav=average(avg1);
				}
				else {
					int num=Integer.parseInt(inFromClient.readLine());
					avg2.add(num);
					finalav=average(avg2);
				}
				
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
			
	}
		
}}
